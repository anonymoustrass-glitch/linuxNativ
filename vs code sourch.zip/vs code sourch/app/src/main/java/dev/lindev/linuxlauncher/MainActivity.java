package dev.lindev.linuxlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String TERMUX_PACKAGE = "com.termux";
    private static final String X11_PACKAGE = "com.termux.x11";
    private static final String TERMUX_HOME = "/data/data/com.termux/files/home";
    private static final String TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash";
    private static final String RUN_COMMAND_ACTION = "com.termux.RUN_COMMAND";
    private static final String X11_RELEASE_URL =
            "https://github.com/termux/termux-x11/releases/tag/nightly";
    private static final String LIME = "#A3E635";
    private static final String MUTED = "#9CA3AF";
    private static final String TEXT = "#F9FAFB";
    private LinearLayout root;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(17, 24, 39));
        getWindow().setNavigationBarColor(Color.rgb(17, 24, 39));
        buildScreen();
        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (root != null) {
            refreshStatus();
        }
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(17, 24, 39));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(32));
        scroll.addView(root);

        TextView brand = text("LINUX HOME  /  DESKTOP", 12, LIME, true);
        brand.setLetterSpacing(0.12f);
        root.addView(brand);

        TextView title = text("Debian desktop,\ndi HP kamu.", 32, TEXT, true);
        title.setPadding(0, dp(18), 0, dp(12));
        root.addView(title);

        TextView intro = text(
                "Desktop XFCE lengkap di layar Android lewat Termux:X11. Tanpa root dan tanpa ganti ROM.",
                16, MUTED, false);
        intro.setLineSpacing(dp(4), 1f);
        root.addView(intro);

        LinearLayout statusCard = card();
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(18), dp(16), dp(18), dp(16));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.topMargin = dp(26);
        root.addView(statusCard, cardParams);

        statusCard.addView(text("STATUS KOMPONEN", 11, MUTED, true));
        status = text("Memeriksa Termux dan Termux:X11…", 15, TEXT, true);
        status.setPadding(0, dp(8), 0, dp(4));
        statusCard.addView(status);
        statusCard.addView(text("Debian memakai kernel Android melalui proot; bukan Linux yang menggantikan Android.", 13, MUTED, false));

        Button setupButton = button("Siapkan Debian + XFCE");
        setupButton.setOnClickListener(view -> setupDesktop());
        addButton(setupButton, dp(22));

        Button desktopButton = button("Jalankan desktop XFCE");
        desktopButton.setOnClickListener(view -> startDesktop());
        addButton(desktopButton, dp(10));

        Button x11Button = button("Pasang aplikasi Termux:X11");
        x11Button.setOnClickListener(view -> openX11ReleasePage());
        addButton(x11Button, dp(10));

        Button shellButton = button("Buka shell Debian");
        shellButton.setOnClickListener(view -> startDebianShell());
        addButton(shellButton, dp(10));

        Button termuxButton = button("Buka Termux");
        termuxButton.setOnClickListener(view -> openTermux());
        addButton(termuxButton, dp(10));

        TextView footnote = text(
                "Perlu Termux dan aplikasi pendamping Termux:X11. Siapkan Debian dulu, pasang APK Termux:X11, lalu jalankan XFCE. Keyboard/mouse Bluetooth opsional.",
                13, MUTED, false);
        footnote.setLineSpacing(dp(3), 1f);
        footnote.setPadding(0, dp(24), 0, 0);
        root.addView(footnote);

        setContentView(scroll);
    }

    private void refreshStatus() {
        if (status == null) {
            return;
        }
        boolean termuxInstalled = isPackageInstalled(TERMUX_PACKAGE);
        boolean x11Installed = isPackageInstalled(X11_PACKAGE);
        status.setText("Termux: " + (termuxInstalled ? "siap" : "belum terpasang")
                + "\nTermux:X11: " + (x11Installed ? "siap" : "belum terpasang"));
        status.setTextColor(termuxInstalled && x11Installed
                ? Color.parseColor(LIME) : Color.parseColor("#FBBF24"));
    }

    private void setupDesktop() {
        if (!isPackageInstalled(TERMUX_PACKAGE)) {
            showTermuxMissingDialog();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Siapkan Debian + XFCE")
                .setMessage("Termux akan menginstal Debian, XFCE, dan D-Bus. Unduhan pertama cukup besar dan perlu internet serta ruang penyimpanan. Aplikasi Termux:X11 dipasang terpisah.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Lanjutkan", (dialog, which) -> runInTermux(
                        "pkg update -y && pkg install -y x11-repo && pkg update -y"
                                + " && pkg install -y termux-x11-nightly proot-distro"
                                + " && (proot-distro list | grep -qi 'debian.*installed'"
                                + " || proot-distro install debian)"
                                + " && proot-distro login debian --shared-tmp -- /bin/bash -lc"
                                + " 'apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y xfce4 dbus-x11'"))
                .show();
    }

    private void startDesktop() {
        if (!isPackageInstalled(TERMUX_PACKAGE)) {
            showTermuxMissingDialog();
            return;
        }
        if (!isPackageInstalled(X11_PACKAGE)) {
            new AlertDialog.Builder(this)
                    .setTitle("Termux:X11 belum terpasang")
                    .setMessage("Pasang APK Termux:X11 dari halaman resmi, lalu kembali ke sini. Termux:X11 harus berasal dari sumber yang cocok dengan instalasi Termux kamu.")
                    .setNegativeButton("Nanti", null)
                    .setPositiveButton("Buka halaman resmi", (dialog, which) -> openX11ReleasePage())
                    .show();
            return;
        }
        runInTermux("termux-x11 :1 >/dev/null 2>&1 &"
                + " sleep 2"
                + " && am start -n com.termux.x11/com.termux.x11.MainActivity"
                + " && proot-distro login debian --shared-tmp -- /bin/bash -lc"
                + " 'export DISPLAY=:1; dbus-launch --exit-with-session xfce4-session'");
    }

    private void startDebianShell() {
        if (!isPackageInstalled(TERMUX_PACKAGE)) {
            showTermuxMissingDialog();
            return;
        }
        runInTermux("proot-distro login debian --shared-tmp -- /bin/bash -l");
    }

    private boolean isPackageInstalled(String packageName) {
        try {
            getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void runInTermux(String command) {
        Intent intent = new Intent(RUN_COMMAND_ACTION);
        intent.setComponent(new ComponentName(TERMUX_PACKAGE, "com.termux.app.RunCommandService"));
        intent.putExtra("com.termux.RUN_COMMAND_PATH", TERMUX_BASH);
        intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-lc", command});
        intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME);
        intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false);
        try {
            startService(intent);
        } catch (SecurityException e) {
            new AlertDialog.Builder(this)
                    .setTitle("Izin Termux diperlukan")
                    .setMessage("Di Termux, aktifkan “Allow external apps” di Settings > Apps, lalu izinkan Linux Home menjalankan perintah. Setelah itu coba lagi.")
                    .setPositiveButton("Buka Termux", (dialog, which) -> openTermux())
                    .setNegativeButton("Tutup", null)
                    .show();
        } catch (ActivityNotFoundException e) {
            showTermuxMissingDialog();
        }
    }

    private void openTermux() {
        try {
            Intent launchIntent = getPackageManager().getLaunchIntentForPackage(TERMUX_PACKAGE);
            if (launchIntent == null) {
                showTermuxMissingDialog();
                return;
            }
            startActivity(launchIntent);
        } catch (ActivityNotFoundException e) {
            showTermuxMissingDialog();
        }
    }

    private void showTermuxMissingDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Termux belum terpasang")
                .setMessage("Pasang Termux dari F-Droid atau halaman resmi GitHub Termux. Jangan gabungkan Termux dari sumber berbeda.")
                .setNegativeButton("Nanti", null)
                .setPositiveButton("Buka F-Droid", (dialog, which) -> {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://f-droid.org/packages/com.termux/"));
                    try {
                        startActivity(browserIntent);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(this, "Browser tidak ditemukan.", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void openX11ReleasePage() {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(X11_RELEASE_URL));
        try {
            startActivity(browserIntent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Browser tidak ditemukan.", Toast.LENGTH_SHORT).show();
        }
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.rgb(31, 41, 55));
        background.setCornerRadius(dp(18));
        layout.setBackground(background);
        return layout;
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(Color.rgb(17, 24, 39));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor(LIME)));
        button.setMinHeight(dp(54));
        button.setGravity(Gravity.CENTER);
        return button;
    }

    private void addButton(Button button, int topMargin) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        params.topMargin = topMargin;
        root.addView(button, params);
    }

    private TextView text(String value, int sizeSp, String color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(Color.parseColor(color));
        if (bold) {
            view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        return view;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
